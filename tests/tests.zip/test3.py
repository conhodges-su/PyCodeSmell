# Duplicate Pair 1: Basic Addition
def add_numbers_v1(a, b):
    return a + b

def add_numbers_v2(a, b):
    return a + b

# Duplicate Pair 2: String Reversal
def reverse_string_v1(s):
    return s[::-1]

def reverse_string_v2(s):
    reversed_str = ""
    for char in s:
        reversed_str = char + reversed_str
    return reversed_str

# Duplicate Pair 3: Find Maximum
def find_max_v1(a, b, c, d, e):
    return max(a, b, c, d, e)

def find_max_v3(a, b, c, d, e):
    return max(a, b, c, d, e)

def find_max_v2(a, b, c, d, e):
    max_value = a
    for num in [b, c, d, e]:
        if num > max_value:
            max_value = num
    return max_value

# Method with at least 25 lines
def process_numbers(lst):
    positives, negatives, zeros = [], [], []
    
    for num in lst:
        if num > 0:
            positives.append(num)
        elif num < 0:
            negatives.append(num)
        else:
            zeros.append(num)

    pos_sum = sum(positives)
    neg_sum = sum(negatives)
    
    pos_avg = pos_sum / len(positives) if positives else 0
    neg_avg = neg_sum / len(negatives) if negatives else 0

    return {
        "positives": positives,
        "negatives": negatives,
        "zeros": zeros,
        "positive_sum": pos_sum,
        "negative_sum": neg_sum,
        "positive_avg": pos_avg,
        "negative_avg": neg_avg,
    }

# Additional unique methods
def is_even(n):
    return n % 2 == 0

def factorial(n):
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result


# --- Calling all methods ---
print("Addition V1:", add_numbers_v1(3, 7))
print("Addition V2:", add_numbers_v2(3, 7))

print("Reverse String V1:", reverse_string_v1("hello"))
print("Reverse String V2:", reverse_string_v2("hello"))

print("Find Max V1:", find_max_v1(5, 12, 8, 20, 7))
print("Find Max V2:", find_max_v2(5, 12, 8, 20, 7))
print("Find Max V3:", find_max_v3(5, 12, 8, 20, 7))

numbers_list = [3, -1, 4, 0, -2, 5, 0, -6, 9]
print("Process Numbers:", process_numbers(numbers_list))

print("Is 10 Even?:", is_even(10))
print("Is 7 Even?:", is_even(7))

print("Factorial of 5:", factorial(5))
print("Factorial of 7:", factorial(7))