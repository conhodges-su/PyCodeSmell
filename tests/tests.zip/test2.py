def add_numbers(a, b):
    result = a + b
    if result > 100:
        return 100
    return result

def add_number(a, b):
    result = a + b
    if result > 100:
        return 100
    return result

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def i_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True


def empty_param(p1, p2, p3, p4, p5=4):
    print("hello")

def empty_param2(p1, p2, p3, p4, p5=4):
    print("hello")

def count():
    num = 10
    for i in range(num):
        print(i)


def countie():
    max = 10
    i = 0
    while(i < max):
        print(i)
        i += 1


print(add_numbers(6, 4))
is_prime(100)
if(True):
    if(True):
        add_numbers(10, 10)
        empty_param()
        is_prime(100)
    else:
        add_number(11, 4)
        empty_param2()
        i_prime(4)
else:
    print(add_numbers(8, 3))
    count()
    is_prime(100)