def long_method():
    print(1)
    print(2)
    print(3)
    print(4)
    print(5)
    print(6)
    print(7)
    print(8)
    print(9)
    print(10)
    print(11)
    print(12)
    print(13)
    print(14)
    print(15)

def not_long_method():
    print(1)
    print(2)
    print(3)

    print(4)
    print(5)
    
    print(6)
    print(7)
    print(8)
    print(9)
    print(10)
    
    print(11)
    
    print(12)
    
    print(13)
    
    print(14)


def long_param(a, b, c, d):
    print(a,b,c,d)

def not_long_param(a, b, c):
    print(a,b,c)