import ast
from sys import argv 

def add_numbers(a, b):
    result = a + b
    if result > 100:
        return 100
    return result

def add_numbers(c, d):
    result = c + d
    if result > 100:
        return 100
    return result


def empty_param(p1, p2, p3, p4, p5=4):
    print("hello")

def empty_param2(p1, p2, p3, p4, p5=4):
    print("hello")

# comment
class PrintVisitor(ast.NodeVisitor):
    def generic_visit(self, node):
        print(f"generic visit{node.__class__.__name__}")
        super().generic_visit(node)

def emptyOrSpacesOnly(line):























    # comment

    return len(line) == 0 or line.isspace()

def removeCodeWhitespaceAndComments(src_code):
    updated_code = []
    for line in src_code.split('\n'):
        if not emptyOrSpacesOnly(line):
            updated_code.append(line)
            print(line)
    return '\n'.join(updated_code)

def getMethodLineCount(code_str):
    updated_code = removeCodeWhitespaceAndComments(code_str)
    count = 0
    for line in updated_code.split('\n'):
        count += 1
    return count 

for item in argv[1:]:
    try:
        with open(item) as fname:
            count = getMethodLineCount(fname.read())
            print(count)
    except SyntaxError as e:
        print(e)
    except OSError as e:
        print(e)


def generate_pattern(size, text):
    if size < 1:
        print("Size must be at least 1")
        return
    
    pattern = []
    
    for i in range(1, size + 1):
        row = " ".join(str(x) for x in range(1, i + 1))
        pattern.append(row)
    
    for line in pattern:
        print(line)
    
    words = text.split()  
    word_count = len(words)  
    char_count = len(text)  
    unique_words = set(words)  
    most_common = max(  
        unique_words, key=lambda w: words.count(w))  
    least_common = min(  
        unique_words, key=lambda w: words.count(w))  
    vowels = sum(1 for c in text if  
                 c.lower() in "aeiou")  
    consonants = sum(1 for c in text  
                     if c.isalpha() and  
                     c.lower() not in "aeiou")  
    digits = sum(1 for c in text  
                 if c.isdigit())  
    spaces = sum(1 for c in text  
                 if c.isspace())  
    
    return pattern


def analyze_text_with_many_words_and_tons_of_lengths_of_method_names(text, v, a, c, f):  
    words = text.split()  
    word_count = len(words)  
    char_count = len(text)  
    unique_words = set(words)  
    most_common = max(  
        unique_words, key=lambda w: words.count(w))  
    least_common = min(  
        unique_words, key=lambda w: words.count(w))  
    vowels = sum(1 for c in text if  
                 c.lower() in "aeiou")  
    consonants = sum(1 for c in text  
                     if c.isalpha() and  
                     c.lower() not in "aeiou")  
    digits = sum(1 for c in text  
                 if c.isdigit())  
    spaces = sum(1 for c in text  
                 if c.isspace())  
    uppercase = sum(1 for c in text  
                    if c.isupper())  
    lowercase = sum(1 for c in text  
                    if c.islower())  
    longest_word = max(words, key=len)  
    shortest_word = min(words, key=len)  
    word_lengths = {w: len(w) for w in  
                    unique_words}  
    avg_length = sum(len(w) for w in words) 
    word_count if word_count else 0  
    contains_numbers = any(c.isdigit()  
                           for c in text)  
    palindromes = [w for w in  
                   unique_words if w ==  
                   w[::-1]]  
    starts_vowel = [w for w in  
                    unique_words if w[0].lower()  
                    in "aeiou"]  
    ends_vowel = [w for w in  
                  unique_words if w[-1].lower()  
                  in "aeiou"]  
    freq_dist = {w: words.count(w) for w  
                 in unique_words}  
    reversed_text = text[::-1]  
    sorted_words = sorted(unique_words)  
    sorted_by_length = sorted(unique_words,  
                               key=len)  
    even_words = [w for w in unique_words  
                  if len(w) % 2 == 0]  
    odd_words = [w for w in unique_words  
                 if len(w) % 2 != 0]  
    print(f"Words: {word_count}")  
    print(f"Chars: {char_count}")  
    print(f"Most common: {most_common}")  
    print(f"Least common: {least_common}")  
    print(f"Vowels: {vowels}")  
    print(f"Consonants: {consonants}")  
    print(f"Digits: {digits}")  
    print(f"Spaces: {spaces}")  
    print(f"Uppercase: {uppercase}")  
    print(f"Lowercase: {lowercase}")  
    print(f"Longest word: {longest_word}")  
    print(f"Shortest word: {shortest_word}")  
    print(f"Avg word length: {avg_length}")  
    print(f"Has numbers: {contains_numbers}")  
    print(f"Palindromes: {palindromes}")  
    print(f"Start vowel: {starts_vowel}")  
    print(f"End vowel: {ends_vowel}")  
    print(f"Freq dist: {freq_dist}")  
    print(f"Reversed: {reversed_text}")  
    print(f"Sorted: {sorted_words}")  
    print(f"By length: {sorted_by_length}")  
    print(f"Even words: {even_words}")  
    print(f"Odd words: {odd_words}")

print(add_numbers(6 + 4))
generate_pattern(5, "any text can be placed here")
empty_param(1,2,3,4)